# StockAIApp

A basic Flutter app template to start your stock market AI-based app.

## Run locally

```bash
flutter pub get
flutter run
```