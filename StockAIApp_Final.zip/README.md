# Stock AI App
A sample AI-powered stock market app built with Flutter.